const Discord = require('discord.js');
const bot = new Discord.Client();
const client = new Discord.Client();

const PREFIX = "w!";
var version = '1.0.1';

const token = 'NzQ1MjA4MzUwMjE5OTYwMzcx.XzubWw.0tMEUrigSNfEbirJfJrMa-Hj9EE'; 

// Status Changes

// Statuses
let statuses = ['Meeting New Users And Welcoming Them', 'Checking Commands', 'Checking Bot Status', 'We Need Members To Make Fun Work! Join Here! https://discord.gg/RkGE4cq'];
client.on('ready', () => {
    setInterval(function() {
        let status = statuses[Math.floor(Math.random()*statuses.length)];

        client.user.setPresence({ game: { name: status }, status: 'dnd' });
     

        client.user.setPresence({ activity: { name: status}, status: 'dnd' })


    }, 10)

})

bot.on('ready', () =>{
    console.log('Bot Launched! YAYYYYYYYYYYYYY');
    bot.user.setActivity('Users And Meeting Them', { type: 'WATCHING'})

})
bot.on('message', msg=>{
    if(msg.content === "w!setup"){
        msg.reply('If You Want Me To Send A Message When Someone Joins The Server, Please Make A Channel Called #welcome , This Will Not DM The User, But Send A Message To The Channel.');
    }
})
bot.on('message', msg=>{
    if(msg.content === "w!help"){
        msg.reply('w!setup > Will Tell You Instuctions On How To Setup This Bot. w!help > Shows This Command To Help You Out With The Commands. w!status > Shows Latest Status About The Bot. w!news > Shows Latest News About The Bot. w!invite > Gives You An Oauth2 Link To Invite The Bot.');
    }
})
bot.on('message', msg=>{
    if(msg.content === "w!info"){
        msg.reply('Status: Stable But Some Commands Are Not Properly Designed And Layed Out.');
    }
})
bot.on('message', msg=>{
    if(msg.content === "w!invite"){
        msg.reply('Invite Me Here And I Only Provided Needed Permissions. https://discord.com/api/oauth2/authorize?client_id=745208350219960371&permissions=15376&redirect_uri=https%3A%2F%2Fdiscord.com%2Fapi%2Foauth2%2Fauthorize%3Fclient_id%3D745208350219960371%26permissions%3D15376%26scope%3Dbot&scope=bot');
    }
})
bot.on('message', msg=>{
    if(msg.content === "w!news"){
        msg.reply('Itz_Seif#0001 Says: I Added Some More Commands. Theyre Probably Needed Too. I Will Add Fun Commands Soon, But For Now, You Got The Main Point Of The Bot.');
    }
})
bot.on('message', msg=>{
    if(msg.content === "w!status"){
        msg.reply('Stable, All Systems And Commands Are Running.');
    }
})
bot.on('message', msg=>{
    if(msg.content === "w!rl"){
        msg.reply('Reloaded The Following:')
        msg.reply(':white_medium_small_square:  index.js')
        msg.reply(':white_medium_small_square: package.json')
        msg.reply(':white_medium_small_square: package-lock.json')
        msg.reply(':x: Did Not Reload Others- Reason: Not Needed.')
    }
})




bot.on('guildMemberAdd', member =>{
    
    const channel = member.guild.channels.cache.find(channel => channel.name === "welcome");
    if(!channel) return; 

    channel.send(`Welcome to the server ${member}, please make sure to read and obey the rules. Make sure to Enjoy!`)

});

bot.login(token)
